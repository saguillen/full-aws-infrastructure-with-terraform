import os
import io
from PIL import Image, ImageDraw, ImageFont
import boto3

s3 = boto3.client('s3')

THUMB_BUCKET = os.environ.get('THUMBNAILS_BUCKET')
WATERMARK_TEXT = os.environ.get('WATERMARK_TEXT', '© 06-demo-final')


def add_watermark(image: Image.Image, text: str) -> Image.Image:
    # Simple watermark: draw semi-transparent text at bottom-right
    watermark = image.convert('RGBA')
    txt_layer = Image.new('RGBA', watermark.size, (255,255,255,0))
    draw = ImageDraw.Draw(txt_layer)
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None

    text_size = draw.textsize(text, font=font)
    padding = 10
    position = (watermark.size[0] - text_size[0] - padding, watermark.size[1] - text_size[1] - padding)
    draw.text(position, text, fill=(255,255,255,128), font=font)
    combined = Image.alpha_composite(watermark, txt_layer)
    return combined.convert('RGB')


def lambda_handler(event, context):
    # Process S3 put events
    for rec in event.get('Records', []):
        s3info = rec.get('s3', {})
        bucket = s3info.get('bucket', {}).get('name')
        key = s3info.get('object', {}).get('key')
        if not bucket or not key:
            continue

        # Download object
        try:
            resp = s3.get_object(Bucket=bucket, Key=key)
            data = resp['Body'].read()
        except Exception as e:
            print(f"Error getting object {bucket}/{key}: {e}")
            continue

        try:
            img = Image.open(io.BytesIO(data))
        except Exception as e:
            print(f"Skipping non-image {key}: {e}")
            continue

        # Create thumbnail
        size = (256, 256)
        img.thumbnail(size)

        # Add watermark
        img = add_watermark(img, WATERMARK_TEXT)

        # Save to buffer
        out_buf = io.BytesIO()
        img.save(out_buf, format='JPEG')
        out_buf.seek(0)

        # Destination key
        dest_key = f"thumbnails/{key.rsplit('/', 1)[-1]}"

        # Upload to thumbnails bucket
        try:
            s3.put_object(Bucket=THUMB_BUCKET, Key=dest_key, Body=out_buf, ContentType='image/jpeg')
            print(f"Saved thumbnail to {THUMB_BUCKET}/{dest_key}")
        except Exception as e:
            print(f"Error uploading thumbnail {THUMB_BUCKET}/{dest_key}: {e}")

    return {'status': 'ok'}
