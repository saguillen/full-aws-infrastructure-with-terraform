from flask import Flask, render_template_string, redirect, url_for
import boto3
import os
import logging

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

THUMBNAILS_BUCKET = os.environ.get('THUMBNAILS_BUCKET')


@app.route('/')
def index():
    s3 = boto3.client('s3')
    if not THUMBNAILS_BUCKET:
        return "THUMBNAILS_BUCKET not configured", 500
    resp = s3.list_objects_v2(Bucket=THUMBNAILS_BUCKET)
    items = resp.get('Contents', []) or []
    images = [obj['Key'] for obj in items]

    # Build a list of dicts with presigned URLs so the thumbnails render even
    # if the bucket is private. If presign fails, fall back to the public S3 URL.
    images_info = []
    for key in images:
        try:
            url = s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': THUMBNAILS_BUCKET, 'Key': key},
                ExpiresIn=3600,
            )
        except Exception as e:
            logging.exception('generate_presigned_url failed for %s: %s', key, e)
            url = f'https://{THUMBNAILS_BUCKET}.s3.amazonaws.com/{key}'
        images_info.append({'key': key, 'url': url})

    html = """<html>
  <head><title>Thumbnails</title></head>
  <body>
    <h1>Thumbnails</h1>
    {% if images %}
      {% for item in images %}
      <div style="display:inline-block; margin:8px; text-align:center;">
        <a href="{{ url_for('get_object', key=item.key) }}" target="_blank" rel="noopener noreferrer">
          <img src="{{ url_for('get_object', key=item.key) }}" alt="thumbnail" style="max-width:200px; display:block; background:#eee;">
        </a>
        <small style="display:block; width:200px; word-break:break-all;">{{ item.key }}</small>
      </div>
      {% endfor %}
    {% else %}
      <p>No thumbnails found.</p>
    {% endif %}
  </body>
</html>"""
    return render_template_string(html, images=images_info)


@app.route('/get/<path:key>')
def get_object(key):
  """Generate a presigned URL for `key` and redirect the client to it.
  This avoids embedding the full presigned query string into the rendered HTML
  and prevents HTML-escaping problems in the page.
  """
  s3 = boto3.client('s3')
  if not THUMBNAILS_BUCKET:
    return "THUMBNAILS_BUCKET not configured", 500
  try:
    url = s3.generate_presigned_url(
      'get_object', Params={'Bucket': THUMBNAILS_BUCKET, 'Key': key}, ExpiresIn=3600
    )
    return redirect(url)
  except Exception:
    logging.exception('failed to presign and redirect for key=%s', key)
    return "failed to get object", 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

